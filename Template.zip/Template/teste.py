from ctypes import alignment
from importlib.metadata import entry_points
from pipes import Template
from tkinter import *
from tkinter.font import BOLD
from turtle import left, width
import mysql.connector
from mysql.connector import Error
from tkinter import messagebox
from tkinter import ttk
from tkinter.messagebox import askyesno
from PIL import ImageTk, Image
from TemplateTelaPython import tela
from TemplateTelaPython import ComunicacaoBanco
import TemplateTelaPython
telaPrincipal = tela()
ComunicacaoBancoPrincipal = ComunicacaoBanco()

TemplateTelaPython.Banco = ComunicacaoBanco.ConectarBanco()

if ComunicacaoBanco.TestarConexaoBanco():
    print("Conexão Ok")
    print(type(TemplateTelaPython.Banco))

TemplateTelaPython.Tabela = 'cidade'
print(TemplateTelaPython.Tabela)

#ComunicacaoBancoPrincipal.mostrarTodosRegistros()
#print(ComunicacaoBancoPrincipal.Dados)



telaPrincipal.mainloop()