from asyncio.windows_events import NULL
from copy import error
from ctypes import alignment
from email.mime import image
from importlib.metadata import entry_points
from logging import exception
from operator import truediv
from sqlite3 import Cursor
from struct import pack
from textwrap import fill
from tkinter import *
from tkinter.font import BOLD
from tkinter.tix import IMAGE
from tokenize import String
from turtle import left, width
import mysql.connector
from mysql.connector import Error
from tkinter import messagebox
from tkinter import ttk
from tkinter.messagebox import askyesno
from PIL import ImageTk, Image


global Host, User, Password, Database, Tabela, Pktabela, Id, Dados, CampoPk, Colunas, Valores

Host = 'localhost'     
User = 'root'
Password = 'acesso123'
Database = 'academico'
Tabela = ''
Pktabela = ''
Id = ''
CampoPk = ''
Banco = mysql.connector.connection_cext.CMySQLConnection
Dados = [object]
Colunas = [String]
Valores = [String]



class ComunicacaoBanco() :
    def __init__(self):
        # Dados para conexão com o banco de dados
        '''
        self.Host = 'localhost'      
        self.User = 'root'
        self.Password = 'acesso123'
        self.Database = 'academico'
        self.Tabela = ''
        self.Pktabela = ''
        self.Id = ''
        self.Dados = any
        '''
    def ConectarBanco():
        banco = mysql.connector.connect(
            host=Host,
            user=User,
            password=Password,
            database=Database
            )
        Banco = banco
        return Banco
    
    
    def TestarConexaoBanco():
        if Banco.is_connected():
            return TRUE
        else:
            return FALSE

    
    def ApagarRegistro():
        deletarReg = messagebox.askyesno('ATENÇÃO', 'Deseja apagar o registro atual?')
        try:
            ex = Error
            if deletarReg:
                stringSql = f" delete * from {Tabela} where cidade_id = 1 "
                if (Dados != NULL):
                    Cursor = Banco.cursor()
                    if ComunicacaoBanco.TestarConexaoBanco():
                        Cursor.execute(stringSql)
                        Banco.commit()
                        messagebox.showinfo('AVISO', 'Registro Apagado com sucesso')
        except Exception as ex:
            messagebox.showerror('ERRO', f"Não foi possivel apagar o registro. Motivo: {str(ex)}")


    # Exibe os registros do banco de dados
    def mostrarTodosRegistros():
        if ComunicacaoBanco.TestarConexaoBanco():
            Cursor = Banco.cursor()
            Cursor.execute(f'SELECT * FROM {Tabela}')
            Dados = Cursor.fetchall()
            print(Dados)
            return Dados



    def inserirRegistro(self):
        try:
            if ComunicacaoBanco.TestarConexaoBanco():
                Cursor = Banco.cursor()
                Cursor.execute("SET SQL_SAFE_UPDATES = 0;")
                Cursor.execute(f"insert into {Tabela} ({Colunas}) values ({Valores});")
                Banco.commit()
        except:
            messagebox.showerror('ERRO', 'Não foi possível inserir o registro')

        # Mostrar o registro selecionado no Grid           
'''
        def mostrar_registro_selecionado(event):
            curItem = grid_reg.focus()
            valor = grid_reg.item(curItem)
            lista_valores = valor['values']
            print('Lista: ', lista_valores)

            # Alterar nomes das caixas (entry)
            entry_01.config(state="normal")
            entry_01.insert(0, lista_valores[0])
            entry_01.config(state="disabled")

            entry_nome.insert(0, lista_valores[1])
            entry_foto.insert(0, lista_valores[2])
            caixa_combo_dias.insert(0, lista_valores[3][8:10])
            caixa_combo_meses.insert(0, lista_valores[3][5:7])    
            caixa_combo_anos.insert(0, lista_valores[3][:4])    
            entry_senha.insert(0, lista_valores[4])
        '''
'''
        # Alterar (update) o registro selecionado no Grid            
        def alterar_registro():
            alterar_reg = messagebox.askyesno('ATENÇÃO', mensagem_bd[7])

            curItem = grid_reg.focus()
            valor = grid_reg.item(curItem)
            lista_valores = valor['values']

            try:
                if alterar_reg:
                    banco = mysql.connector.connect(
                        host=hostX,
                        user=userX,
                        password=passwordX,
                        database=databaseX
                    )
                    if banco.is_connected():
                        dados = [(lista_valores[0])]
                        cursorX.execute(comando_sql_seguranca)
                        #cursor.execute("UPDATE usarios SET nome_user = ", str(entry_nome.get()), "path_foto_user = ", str(entry_foto.get(), "senha_user = ", str(entry_senha.get() WHERE  ) 
                        # " 'Joaquim' WHERE placa = 'ABC-1234'")
                        cursorX.execute(comando_sql_deletar, dados)
                        banco.commit()
            except:
                messagebox.showerror('ERRO', mensagem_bd[5])
        '''
    


        ################################################
class tela(Tk) :
    def __init__(self):
        Tk.__init__(self)
    
        # Janela principal
        
        #self = Tk()
        self.title('Sistema acadêmico')
        self.geometry('800x600')
        #janela.state('zoomed')
        self.configure(bg='#EDE6E6')
        self.resizable(width=True, height=True)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        ###############################################
        
        #Height = 150
        #label cadasto
        self.labelCadastro = Label(self, fg='white smoke', bg='#FFFFFF', borderwidth=0, justify='center', width=800, height=3)
        self.labelCadastro.pack(side=TOP)
        self.labelCadastro.location(x=0, y=0)
        #labelCadastro.place()
        ################################################
        
        #entry indice de código
        self.entryIndice = Entry(self.labelCadastro,relief='flat', font=('','12') , fg='black', bg='Alice Blue', highlightbackground='black', highlightcolor='black', highlightthickness='1', state=DISABLED, justify=CENTER)
        self.entryIndice.place(x=550,y=7,width=100,height=30)
        ################################################

        # Botões
        #Botão inserir
        self.iconInserir = ImageTk.PhotoImage(file="16x16-free-application-icons/ico/Add.ico")
        self.botaoInserir = Button(self.labelCadastro, relief='flat', font=('','12') , fg='black', activeforeground='orange', bg='orange', image=self.iconInserir, command=self.ClickBotaoInserir)
        self.botaoInserir.place(x=30,y=7,width=30,height=30)
        ################################################

        #Botão excluir
        self.iconExcluir = ImageTk.PhotoImage(file="16x16-free-application-icons/ico/Erase.ico")
        self.botaoExcluir = Button(self.labelCadastro,relief='flat', font=('','12') , fg='black', activeforeground='orange', bg='orange', image=self.iconExcluir)
        self.botaoExcluir.place(x=90,y=7,width=30,height=30)
        ################################################
        
        #Botão NovaPesquisa
        self.iconNovaPesquisa = ImageTk.PhotoImage(file="16x16-free-application-icons/ico/Text preview.ico")
        self.botaoNovaPesquisa = Button(self.labelCadastro, relief='flat', font=('','12') , fg='black', activeforeground='orange', bg='orange', image=self.iconNovaPesquisa)
        self.botaoNovaPesquisa.place(x=180,y=7,width=30,height=30)
        ################################################

        #Botão Pesqusisar
        self.iconPesquisar = ImageTk.PhotoImage(file="16x16-free-application-icons/ico/View.ico")
        self.botaoPesqusisar = Button(self.labelCadastro,relief='flat', font=('','12') , fg='black', activeforeground='orange', bg='orange', image=self.iconPesquisar, command=self.ClickBotaoPesquisar)
        self.botaoPesqusisar.place(x=240,y=7,width=30,height=30)
        ################################################
        
        #Botão PrimeiroCodigo
        self.iconPrimeiroCodigo = ImageTk.PhotoImage(file="16x16-free-application-icons/ico/First.ico")
        self.botaoPrimeiroCodigo = Button(self.labelCadastro, relief='flat', font=('','12') , fg='black', activeforeground='orange', bg='orange', image=self.iconPrimeiroCodigo)
        self.botaoPrimeiroCodigo.place(x=450,y=7,width=30,height=30)
        ################################################

        #Botão CodigoAnterior
        self.iconCodigoAnterior = ImageTk.PhotoImage(file="16x16-free-application-icons/ico/Back.ico")
        self.botaoCodigoAnterior = Button(self.labelCadastro,relief='flat', font=('','12') , fg='black', activeforeground='orange', bg='orange', image=self.iconCodigoAnterior)
        self.botaoCodigoAnterior.place(x=500,y=7,width=30,height=30)
        ################################################
        
        #Botão ProximoCodigo
        self.iconProximoCodigo = ImageTk.PhotoImage(file="16x16-free-application-icons/ico/Forward.ico")
        self.botaoProximoCodigo = Button(self.labelCadastro, relief='flat', font=('','12') , fg='black', activeforeground='orange', bg='orange', image=self.iconProximoCodigo)
        self.botaoProximoCodigo.place(x=670,y=7,width=30,height=30)
        ################################################

        #Botão UltimoCodigo
        self.iconUltimoCodigo = ImageTk.PhotoImage(file="16x16-free-application-icons/ico/Last.ico")
        self.botaoUltimoCodigo = Button(self.labelCadastro,relief='flat', font=('','12') , fg='black', activeforeground='orange', bg='orange', image=self.iconUltimoCodigo)
        self.botaoUltimoCodigo.place(x=720,y=7,width=30,height=30)
        ################################################
        
        #Eventos
        ################################################
    def ClickBotaoPesquisar(self):
        ComunicacaoBanco.mostrarTodosRegistros();
        
    def ClickBotaoInserir(self):
        ComunicacaoBanco.InserirNovoRegistro();

